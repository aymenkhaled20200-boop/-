# Jibli Play Store Release Checklist

- Application ID: com.jibli.app
- Version: 1.0.0 (versionCode 1)
- Build type: release
- Target SDK: 35
- Generate signed Android App Bundle (.aab)
- Create Play Console developer account and complete verification
- Prepare app icon and screenshots
- Add official support email and privacy-policy URL
- Complete Data Safety form accurately based on the production backend
- Test the release build on physical Android devices
- Complete any testing requirement shown by Play Console
- Upload AAB and submit for review
