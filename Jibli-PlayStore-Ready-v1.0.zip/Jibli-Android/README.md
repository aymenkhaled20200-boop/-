# Jibli Android MVP

نسخة Android أولية لتطبيق الحريف Jibli، مبنية حول واجهة الـMVP الحالية داخل WebView.

## الموجود الآن
- تطبيق Android باسم Jibli | جيبلي
- واجهة الحريف الحالية داخل assets
- JavaScript وLocalStorage للنسخة التجريبية
- مشروع Gradle Android قابل للبناء عند توفر Android SDK + Gradle/Android Studio

## ملاحظة مهمة
هذه ليست نسخة إنتاجية بعد: قاعدة البيانات، تسجيل الدخول، الإشعارات، مزامنة الطلبات بين الحريف ولوحة الإدارة، ونظام الموصّل تحتاج Backend حقيقي.

## المسار المتفق عليه
الحريف → Jibli Admin (أنت) → اتصال بالمطعم → الموصّل → الحريف

## الخطوة التالية
ربط المشروع بـBackend (Firebase أو Supabase) وإنشاء حالات الطلب والإشعارات، ثم توقيع Release وبناء AAB للنشر في Google Play.
