# Jibli — Play Store preparation

This project is configured for a release build with version 1.0.0 and application ID `com.jibli.app`.

The final signed AAB cannot be produced in the current environment because the Android SDK/build toolchain and a user-owned signing key are not available here.

Before production publication, connect the real backend and replace the preliminary privacy policy with the final policy describing actual data collection, storage, analytics, notifications, maps, and other services used by Jibli.
